﻿namespace Roomz.Models
{
    public class Schedule
    {
        public decimal Price { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
